#include <config.h>
#define XSIZE_INLINE _GL_EXTERN_INLINE
#include "xsize.h"
